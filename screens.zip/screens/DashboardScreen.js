import React, { useEffect, useState } from "react";
import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  TouchableOpacity,
  Linking,
  ImageBackground,
  Image,
} from "react-native";
import AsyncStorage from "@react-native-async-storage/async-storage";
import careerRoadmaps from "../data/careerRoadmaps";
import careerEmojis from "../data/careerEmojis";
import * as Print from "expo-print";
import * as FileSystem from "expo-file-system";
import * as Sharing from "expo-sharing";
import { useNavigation } from "@react-navigation/native";
import { useThemeStyles } from "../hooks/useThemeStyles";
import useNetworkStatus from "../hooks/useNetworkStatus";
import OfflineBanner from "../components/OfflineBanner";
import NetworkBanner from "../components/NetworkBanner";
import { useTranslation } from "react-i18next";
import { styles3D } from "../styles/globalStyles";
import ThreeDButton from "../components/ThreeDButton";

const DashboardScreen = () => {
  const [savedCareers, setSavedCareers] = useState([]);
  const navigation = useNavigation();
  const { colors } = useThemeStyles();
  const isConnected = useNetworkStatus();
  const { t } = useTranslation();

  useEffect(() => {
    const loadCareers = async () => {
      const stored = JSON.parse(await AsyncStorage.getItem("savedCareers") || "[]");
      const full = stored
        .map((title) => careerRoadmaps[title] && { title, ...careerRoadmaps[title] })
        .filter(Boolean);
      setSavedCareers(full);
    };
    loadCareers();
  }, []);

  const handleRemoveCareer = async (titleToRemove) => {
    const updated = savedCareers.filter((c) => c.title !== titleToRemove);
    setSavedCareers(updated);
    const titles = updated.map((c) => c.title);
    await AsyncStorage.setItem("savedCareers", JSON.stringify(titles));
  };

  const clearDashboard = async () => {
    await AsyncStorage.removeItem("savedCareers");
    setSavedCareers([]);
  };

  const exportToJSON = async () => {
    const blob = JSON.stringify(savedCareers, null, 2);
    const path = FileSystem.documentDirectory + "career-paths.json";
    await FileSystem.writeAsStringAsync(path, blob);
    await Sharing.shareAsync(path);
  };

  const exportToPDF = async () => {
    const html = `
      <html><body>
        <h1>${t("dashboard.exportTitle")}</h1>
        ${savedCareers
          .map(
            (c) => `
              <h2>${c.title}</h2>
              <p><strong>${t("dashboard.skills")}:</strong> ${c.skills?.join(", ")}</p>
              <p><strong>${t("dashboard.roadmap")}:</strong></p>
              <ul>${c.roadmap?.map((step) => `<li>${step}</li>`).join("")}</ul>
              <p><strong>${t("dashboard.resources")}:</strong></p>
              <ul>${c.resources?.map((r) => `<li>${r}</li>`).join("")}</ul>
            `
          )
          .join("<hr/>")}
      </body></html>
    `;
    const { uri } = await Print.printToFileAsync({ html });
    await Sharing.shareAsync(uri);
  };

  return (
    <ImageBackground
      source={require("../assets/splash/splash.png")}
      style={{ flex: 1 }}
      imageStyle={{
        opacity: 0.04,
        resizeMode: "contain",
      }}
    >
      <ScrollView contentContainerStyle={[styles.container]} style={{ backgroundColor: colors.background }}>
        <NetworkBanner isConnected={isConnected} />
        {!isConnected && <OfflineBanner />}
        <Text style={[styles.title, { color: colors.text }]}>📁 {t("dashboard.savedTitle")}</Text>
        <View style={{ flexDirection: "row", alignItems: "center", marginBottom: 16 }}>
  <TouchableOpacity
    onPress={() => navigation.navigate("Main", { screen: "Home" })}
    style={{
      backgroundColor: "#e0e7ff",
      paddingVertical: 10,
      paddingHorizontal: 15,
      borderRadius: 10,
      shadowColor: "#000",
      shadowOffset: { width: 0, height: 3 },
      shadowOpacity: 0.25,
      shadowRadius: 4,
      elevation: 6, // Android shadow
      marginVertical: 6,
    }}
  >
    <Text style={{ fontSize: 16, color: "#1e3a8a", fontWeight: "bold", textAlign: "center" }}>
      ← {t("backHome")}
    </Text>
  </TouchableOpacity>
</View>

        {savedCareers.length === 0 ? (
          <View style={styles.emptyBox}>
            <Text style={[styles.emptyText, { color: colors.text }]}>
              📭 {t("dashboard.empty")}
            </Text>
          </View>
        ) : (
          <>
            {savedCareers.map((career, index) => (
              <View key={index} style={[styles.card, { backgroundColor: colors.card, borderColor: colors.border }]}>
                <View style={styles.cardHeader}>
                  <View
                    style={{
                      backgroundColor: "#e0e7ff",
                      paddingVertical: 6,
                      paddingHorizontal: 12,
                      borderRadius: 20,
                      flexDirection: "row",
                      alignItems: "center",
                      gap: 6,
                    }}
                  >
                                  {/* ✅ Watermark inside card */}
                                  <Image
                                    source={require("../assets/splash/splash.png")}
                                    style={{
                                      position: "absolute",
                                      width: 93,
                                      height: 93,
                                      opacity: 0.25,
                                      borderRadius: 46,
                                      top: -15,
                                      left: 260,
                                      zIndex: -1,
                                    }}
                                  />
                    <Text style={{ fontSize: 18 }}>{careerEmojis[career.title] || "💼"}</Text>
                    <Text style={{ fontSize: 16, fontWeight: "bold", color: "#1e3a8a" }}>{career.title}</Text>
                  </View>
                </View>

                <Text style={[styles.sectionLabel, { color: colors.text }]}>{t("dashboard.skills")}:</Text>
                <View style={styles.skillContainer}>
                  {career.skills?.map((skill, i) => (
                    <Text key={i} style={styles.skillTag}>{skill}</Text>
                  ))}
                </View>

                <Text style={[styles.sectionLabel, { color: colors.text }]}>{t("dashboard.roadmap")}:</Text>
                {career.roadmap?.slice(0, 10).map((step, i) => (
                  <Text key={i} style={[styles.bulletText, { color: colors.text }]}>• {step}</Text>
                ))}

                {career.resources?.length > 0 && (
                  <>
                    <Text style={[styles.sectionLabel, { color: colors.text }]}>{t("dashboard.resources")}:</Text>
                    {career.resources.slice(0, 8).map((link, i) => (
                      <Text
                        key={i}
                        style={[styles.linkText, { color: "#1E90FF"}]}
                        onPress={() => Linking.openURL(link)}
                      >
                        🔗 {link}
                      </Text>
                    ))}
                  </>
                )}

                <ThreeDButton
                  title={t("dashboard.delete")}
                  onPress={() => handleRemoveCareer(career.title)}
                  gradient
                  style={{ backgroundColor: "#dc2626" }}
                />
              </View>
            ))}
            <View style={styles.actions}>
              <TouchableOpacity style={styles.primaryBtn} onPress={exportToPDF}>
                <Text style={styles.btnText}>{t("dashboard.exportPdf")}</Text>
              </TouchableOpacity>

              <TouchableOpacity
                style={[styles.primaryBtn, { backgroundColor: "#059669" }]}
                onPress={exportToJSON}
              >
                <Text style={styles.btnText}>{t("dashboard.exportJson")}</Text>
              </TouchableOpacity>

              <TouchableOpacity
                style={[styles.primaryBtn, { backgroundColor: "#ef4444" }]}
                onPress={clearDashboard}
              >
                <Text style={styles.btnText}>{t("dashboard.clear")}</Text>
              </TouchableOpacity>

              <TouchableOpacity
                style={[styles.primaryBtn, { backgroundColor: "#6b7280" }]}
                onPress={() => navigation.navigate("Main", { screen: "Home" })}
              >
                <Text style={styles.btnText}>← {t("backHome")}</Text>
              </TouchableOpacity>
            </View>
          </>
        )}
      </ScrollView>
    </ImageBackground>
  );
};

export default DashboardScreen;

const styles = StyleSheet.create({
  container: {
    flexGrow: 1,
    padding: 16,
    backgroundColor: "transparent",
  },
  title: {
    fontSize: 24,
    fontWeight: "bold",
    marginTop: 32,
    marginBottom: 16,
    textAlign: "center",
  },
  card: {
    borderWidth: 1,
    borderRadius: 12,
    padding: 16,
    marginBottom: 16,
    elevation: 4,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.12,
    shadowRadius: 6,
  },
  cardHeader: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 10,
  },
  sectionLabel: {
    fontWeight: "600",
    marginTop: 12,
    marginBottom: 6,
    color: "#374151",
  },
  skillContainer: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: 6,
  },
  skillTag: {
    backgroundColor: "#e0e7ff",
    color: "#1e3a8a",
    fontSize: 12,
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 999,
    marginRight: 6,
    marginBottom: 6,
  },
  bulletText: {
    fontSize: 14,
    marginBottom: 4,
    paddingLeft: 4,
  },
  linkText: {
    fontSize: 13,
    marginBottom: 4,
    textDecorationLine: "underline",
  },
  primaryBtn: {
    backgroundColor: "#4f46e5",
    paddingVertical: 12,
    paddingHorizontal: 24,
    borderRadius: 8,
    marginBottom: 10,
  },
  btnText: {
    color: "#fff",
    fontWeight: "bold",
  },
  actions: {
    marginTop: 20,
    alignItems: "center",
    gap: 10,
  },
  emptyBox: {
    alignItems: "center",
    marginTop: 50,
  },
  emptyText: {
    fontSize: 16,
    color: "#6b7280",
    marginBottom: 16,
    textAlign: "center",
  },
});