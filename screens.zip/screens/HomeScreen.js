import React from "react";
import { View, Text, StyleSheet, TouchableOpacity, Image } from "react-native";
import { useNavigation } from "@react-navigation/native";
import { useThemeStyles } from "../hooks/useThemeStyles";
import { useTranslation } from "react-i18next";
import { APP_NAME } from "../constants/appInfo";
import { styles3D } from "../styles/globalStyles";

const HomeScreen = () => {
  const navigation = useNavigation();
  const { colors } = useThemeStyles();
  const { t } = useTranslation();

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      {/* 🌟 Logo */}
      <Image
        source={require("../assets/splash/splash.png")}
        style={{ width: 100, height: 100, borderRadius: 50, resizeMode: "cover", marginBottom: 16, opacity: 0.8 }}
      />

     <Text style={[styles.title, { color: colors.text }]}>{APP_NAME}</Text>

      <Text style={[styles.description, { color: colors.text }]}>
        {t("appSubtitle")}
      </Text>

      <TouchableOpacity style={[styles3D.button, {backgroundColor: "#4f46e5"}]}
        onPress={() => navigation.navigate("Questionnaire")}
      >
        <Text style={styles3D.buttonText}>{t("startQuiz")}</Text>
      </TouchableOpacity>

      <TouchableOpacity 
      style={[styles3D.button, {backgroundColor: "#708090"}]}
      onPress={() => navigation.navigate("CareerExplorer")}>
        <Text style={styles3D.buttonText}>{t("careerExplorer.title")}</Text>
      </TouchableOpacity>
    </View>
  );
};

export default HomeScreen;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 24,
    justifyContent: "center",
    alignItems: "center",
  },
  title: {
    fontSize: 26,
    fontWeight: "bold",
    marginBottom: 10,
    textAlign: "center",
  },
  description: {
    fontSize: 16,
    textAlign: "center",
    marginBottom: 24,
  },
  button: {
    paddingVertical: 14,
    paddingHorizontal: 32,
    borderRadius: 10,
    marginBottom: 16,
  },
  secondaryButton: {
    paddingVertical: 14,
    paddingHorizontal: 28,
    borderRadius: 10,
  },
  buttonText: {
    color: "#fff",
    fontWeight: "bold",
    fontSize: 16,
  },
});