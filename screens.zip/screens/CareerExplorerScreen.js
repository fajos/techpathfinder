
import React, { useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  TextInput,
  ScrollView,
  TouchableOpacity,
  Linking,
} from "react-native";
import careerRoadmaps from "../data/careerRoadmaps";
import { useThemeStyles } from "../hooks/useThemeStyles";
import { useTranslation } from "react-i18next";
import careerEmojis from "../data/careerEmojis";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { useNavigation } from "@react-navigation/native";

const CareerExplorerScreen = () => {
  const { colors } = useThemeStyles();
  const { t } = useTranslation();
  const [query, setQuery] = useState("");
  const [savedTitles, setSavedTitles] = useState([]);

  const navigation = useNavigation();

  const filteredCareers = Object.keys(careerRoadmaps)
    .filter((title) => title.toLowerCase().includes(query.toLowerCase()))
    .map((title) => ({ title, ...careerRoadmaps[title] }));

  const handleSave = async (title) => {
    const existing = JSON.parse(await AsyncStorage.getItem("savedCareers") || "[]");
    const updated = [...new Set([...existing, title])];
    await AsyncStorage.setItem("savedCareers", JSON.stringify(updated));
    setSavedTitles(updated);
  };

  return (
    <ScrollView style={[styles.container, { backgroundColor: colors.background }]}>
      <Text style={[styles.title, { color: colors.text }]}>
        {t("explorer.title", "🔍 Explore Tech Careers")}
      </Text>
      <View style={{ flexDirection: "row", alignItems: "center", marginBottom: 16 }}>
  <TouchableOpacity
    onPress={() => navigation.navigate("Main", { screen: "Home" })}
    style={{
      backgroundColor: "#e0e7ff",
      paddingVertical: 10,
      paddingHorizontal: 15,
      borderRadius: 10,
      shadowColor: "#000",
      shadowOffset: { width: 0, height: 3 },
      shadowOpacity: 0.25,
      shadowRadius: 4,
      elevation: 6, // Android shadow
      marginVertical: 6,
    }}
  >
    <Text style={{ fontSize: 16, color: "#1e3a8a", fontWeight: "bold" }}>
      ← {t("backHome")}
    </Text>
  </TouchableOpacity>
</View>

      <TextInput
        placeholder={t("explorer.search", "Search careers...")}
        placeholderTextColor={colors.border}
        style={[styles.searchBox, { color: colors.text, borderColor: colors.border }]}
        onChangeText={setQuery}
        value={query}
      />

      {filteredCareers.map((career) => (
        <View key={career.title} style={[styles.card, { backgroundColor: colors.card }]}>
          <View style={{ flexDirection: "row", alignItems: "center", marginBottom: 10 }}>
            <Text style={styles.emoji}>{careerEmojis[career.title] || "💼"}</Text>
            <Text style={[styles.cardTitle, { color: colors.text}]}>{career.title}</Text>
          </View>

          <Text style={[styles.label, { color: colors.text }]}>
            {t("dashboard.skills", "Top Skills")}:
          </Text>
          <View style={styles.skillContainer}>
            {career.skills?.map((s, i) => (
              <Text key={i} style={styles.skillTag}>{s}</Text>
            ))}
          </View>

          <Text style={[styles.label, { color: colors.text }]}>
            {t("dashboard.roadmap", "Roadmap")}:
          </Text>
          {career.roadmap?.map((step, i) => (
            <Text key={i} style={[styles.step, { color: colors.text }]}>• {step}</Text>
          ))}

          {career.resources?.length > 0 && (
            <>
              <Text style={[styles.label, { color: colors.text }]}>
                {t("dashboard.resources", "Resources")}:
              </Text>
              {career.resources.slice(0, 5).map((link, i) => (
                <Text
                  key={i}
                  style={[styles.link, { color: "#1E90FF" }]}
                  onPress={() => Linking.openURL(link)}
                >
                  🔗 {link}
                </Text>
              ))}
            </>
          )}

          <TouchableOpacity
            onPress={() => handleSave(career.title)}
            disabled={savedTitles.includes(career.title)}
            style={[
              styles.saveBtn,
              { backgroundColor: savedTitles.includes(career.title) ? "#9ca3af" : "#4f46e5" },
            ]}
          >
            <Text style={styles.saveText}>
              {savedTitles.includes(career.title)
                ? t("dashboard.saved", "✔ Saved")
                : t("dashboard.saveToDashboard", "Save to Dashboard")}
            </Text>
          </TouchableOpacity>
        </View>
      ))}
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    padding: 16,
  },
  title: {
    fontSize: 22,
    fontWeight: "bold",
    marginTop: 32,
    marginBottom: 16,
    textAlign: "center",
  },
  searchBox: {
    borderWidth: 1,
    borderRadius: 10,
    padding: 10,
    marginBottom: 20,
    fontSize: 16,
  },
  card: {
    borderRadius: 12,
    padding: 16,
    marginBottom: 20,
    borderWidth: 1,
    borderColor: "#e5e7eb",
  },
  emoji: {
    fontSize: 22,
    marginRight: 8,
  },
  cardTitle: {
    fontSize: 18,
    fontWeight: "bold",
  },
  label: {
    fontWeight: "600",
    marginTop: 8,
    marginBottom: 4,
  },
  skillContainer: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: 6,
    marginBottom: 6,
  },
  skillTag: {
    backgroundColor: "#e0e7ff",
    color: "#1e3a8a",
    fontSize: 12,
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 999,
    marginRight: 6,
    marginBottom: 6,
  },
  step: {
    fontSize: 14,
    marginBottom: 4,
  },
  link: {
    fontSize: 13,
    textDecorationLine: "underline",
    marginBottom: 3,
  },
  saveBtn: {
    marginTop: 10,
    paddingVertical: 10,
    borderRadius: 8,
    alignItems: "center",
  },
  saveText: {
    color: "white",
    fontWeight: "bold",
  },
});

export default CareerExplorerScreen;
