import React, { useEffect, useState } from "react";
import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  TouchableOpacity,
  Linking,
  Image,
} from "react-native";
import AsyncStorage from "@react-native-async-storage/async-storage";
import careerEmojis from "../data/careerEmojis";
import { useThemeStyles } from "../hooks/useThemeStyles";
import useNetworkStatus from "../hooks/useNetworkStatus";
import OfflineBanner from "../components/OfflineBanner";
import NetworkBanner from "../components/NetworkBanner";
import CareerModal from "../components/CareerModal";
import { useTranslation } from "react-i18next";
import { styles3D } from "../styles/globalStyles";

const ResultTabScreen = () => {
  const { isDark, colors } = useThemeStyles();
  const [results, setResults] = useState([]);
  const isConnected = useNetworkStatus();
  const [savedTitles, setSavedTitles] = useState([]);
  const [selectedCareer, setSelectedCareer] = useState(null);
  const [modalVisible, setModalVisible] = useState(false);
  const { t } = useTranslation();

  const openModal = (career) => {
    setSelectedCareer(career);
    setModalVisible(true);
  };

  const closeModal = () => {
    setSelectedCareer(null);
    setModalVisible(false);
  };

  useEffect(() => {
    const load = async () => {
      const stored = await AsyncStorage.getItem("lastCareerResult");
      const saved = await AsyncStorage.getItem("savedCareers") || "[]";
      if (stored) setResults(JSON.parse(stored));
      setSavedTitles(JSON.parse(saved));
    };
    load();
  }, []);

  const handleSaveSingle = async (title) => {
    const updated = [...new Set([...savedTitles, title])];
    await AsyncStorage.setItem("savedCareers", JSON.stringify(updated));
    setSavedTitles(updated);
  };

  if (!results || results.length === 0) {
    return (
      <View style={[styles.container, { backgroundColor: colors.background }]}>
        <Text style={[styles.emptyText, { color: colors.text }]}>
          📭 {t("resultTab.empty")}
        </Text>
      </View>
    );
  }

  return (
    <ScrollView style={[styles.container, { backgroundColor: colors.background }]}>
      <NetworkBanner isConnected={isConnected} />
      {!isConnected && <OfflineBanner />}

      <Text style={[styles.screenTitle, { color: colors.text }]}>
        🎯 {t("resultTab.title")}
      </Text>

      {results.map((career) => {
        const isSaved = savedTitles.includes(career.title);
        return (
          <TouchableOpacity
            key={career.title}
            onPress={() => openModal(career)}
            activeOpacity={0.9}
          >
            <View style={[styles.card, { backgroundColor: colors.card }]}>
              {/* ✅ Watermark inside card */}
              <Image
                source={require("../assets/splash/splash.png")}
                style={{
                  position: "absolute",
                  width: 93,
                  height: 93,
                  opacity: 0.25,
                  borderRadius: 46,
                  top: 0,
                  right: 10,
                  zIndex: -1,
                }}
              />

              <View style={{ flexDirection: "row", alignItems: "center", marginBottom: 12 }}>
                <View
                  style={{
                    backgroundColor: "#e0e7ff",
                    paddingVertical: 6,
                    paddingHorizontal: 12,
                    borderRadius: 20,
                    flexDirection: "row",
                    alignItems: "center",
                  }}
                >
                  <Text style={{ fontSize: 18 }}>{careerEmojis[career.title] || "💼"}</Text>
                  <Text
                    style={{
                      fontSize: 16,
                      fontWeight: "bold",
                      marginLeft: 8,
                      color: "#1e3a8a",
                    }}
                  >
                    {career.title}
                  </Text>
                </View>
              </View>

              <Text style={[styles.sectionTitle,{ color: colors.text }]}>{t("dashboard.skills")}:</Text>
              <View style={styles.skillContainer}>
                {career.skills?.map((skill) => (
                  <Text key={career.title + "_skill_" + skill} style={styles.skillTag}>
                    {skill}
                  </Text>
                ))}
              </View>

              <Text style={[styles.sectionTitle,{ color: colors.text }]}>{t("dashboard.roadmap")}:</Text>
              {career.roadmap?.slice(0, 5).map((step) => (
                <Text key={career.title + "_step_" + step} style={[styles.smallText, {color: colors.text}]}>
                  • {step}
                </Text>
              ))}

              {career.resources?.length > 0 && (
                <>
                  <Text style={[styles.sectionTitle, {color: colors.text}]}>{t("dashboard.resources")}:</Text>
                  {career.resources.slice(0, 3).map((link) => (
                    <Text
                      key={career.title + "_link_" + link}
                      style={styles.link}
                      onPress={() => Linking.openURL(link)}
                    >
                      🔗 {link}
                    </Text>
                  ))}
                </>
              )}

              <TouchableOpacity
                onPress={() => handleSaveSingle(career.title)}
                disabled={isSaved}
                style={[
                  styles3D.button,
                  { backgroundColor: isSaved ? "#9ca3af" : "#4f46e5" },
                ]}
              >
                <Text style={styles3D.buttonText}>
                  {isSaved ? `✔ ${t("dashboard.saved")}` : t("dashboard.saveToDashboard")}
                </Text>
              </TouchableOpacity>
            </View>
          </TouchableOpacity>
        );
      })}

      <CareerModal visible={modalVisible} onClose={closeModal} career={selectedCareer} />
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    padding: 16,
    flex: 1,
  },
  screenTitle: {
    fontSize: 22,
    fontWeight: "bold",
    marginTop: 32,
    marginBottom: 16,
    textAlign: "center",
  },
  emptyText: {
    fontSize: 16,
    textAlign: "center",
    marginTop: 50,
  },
  skillContainer: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: 6,
    marginTop: 5,
    marginBottom: 10,
  },
  skillTag: {
    backgroundColor: "#e0e7ff",
    color: "#1e3a8a",
    fontSize: 12,
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 999,
    marginRight: 6,
    marginBottom: 6,
  },
  card: {
    borderWidth: 1,
    borderRadius: 12,
    padding: 16,
    marginBottom: 20,
    elevation: 4,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.12,
    shadowRadius: 6,
    overflow: "hidden",
  },
  sectionTitle: {
    fontWeight: "600",
    marginTop: 8,
    marginBottom: 4,
    fontSize: 15,
  },
  smallText: {
    fontSize: 14,
    marginBottom: 4,
  },
  button: {
    backgroundColor: "#2563eb",
    paddingVertical: 12,
    paddingHorizontal: 24,
    borderRadius: 8,
    marginTop: 7,
    marginBottom: 8,
  },
  buttonText: {
    color: "white",
    fontWeight: "bold",
    textAlign: "center",
  },
  link: {
    fontSize: 13,
    marginTop: 2,
    textDecorationLine: "underline",
    color: "#2563eb",
  },
});

export default ResultTabScreen;