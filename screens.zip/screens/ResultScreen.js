import React, { useState, useEffect, useRef, useContext } from "react";
import {
  View,
  Text,
  TouchableOpacity,
  Platform,
  Alert,
  ToastAndroid,
  ScrollView,
  StyleSheet,
  Linking,
  Animated,
  Share,
  Image,
} from "react-native";
import { useRoute, useNavigation } from "@react-navigation/native";
import AsyncStorage from "@react-native-async-storage/async-storage";
import mapAnswersToCareers from "../utils/mapAnswersToCareers";
import careerRoadmaps from "../data/careerRoadmaps";
import careerEmojis from "../data/careerEmojis";
import { useThemeStyles } from "../hooks/useThemeStyles";
import { ThemeContext } from "../utils/ThemeContext";
import ConfettiCannon from "react-native-confetti-cannon";
import useNetworkStatus from "../hooks/useNetworkStatus";
import OfflineBanner from "../components/OfflineBanner";
import NetworkBanner from "../components/NetworkBanner";
import CareerModal from "../components/CareerModal";
import { useTranslation } from "react-i18next";
import ThreeDButton from "../components/ThreeDButton";

const ResultScreen = () => {
  const route = useRoute();
  const navigation = useNavigation();
  const { answers } = route.params || {};
  const { isDark } = useContext(ThemeContext);
  const isConnected = useNetworkStatus();
  const { colors } = useThemeStyles();
  const { t } = useTranslation();

  const careerTitles = mapAnswersToCareers(answers);
  const fullResults = careerTitles
    .map((title) => careerRoadmaps[title] && { title, ...careerRoadmaps[title] })
    .filter(Boolean);

  const fadeAnim = useRef(new Animated.Value(0)).current;
  const [saved, setSaved] = useState(false);
  const [showConfetti, setShowConfetti] = useState(true);
  const [savedTitles, setSavedTitles] = useState([]);
  const [selectedCareer, setSelectedCareer] = useState(null);
  const [modalVisible, setModalVisible] = useState(false);

  const openModal = (career) => {
    setSelectedCareer(career);
    setModalVisible(true);
  };

  const closeModal = () => {
    setSelectedCareer(null);
    setModalVisible(false);
  };

  useEffect(() => {
    const fetchSaved = async () => {
      const existing = JSON.parse(await AsyncStorage.getItem("savedCareers") || "[]");
      setSavedTitles(existing);
    };
    fetchSaved();
  }, []);

  useEffect(() => {
    const timer = setTimeout(() => {
      setShowConfetti(false);
    }, 4000);
    return () => clearTimeout(timer);
  }, []);

  useEffect(() => {
    Animated.timing(fadeAnim, {
      toValue: 1,
      duration: 600,
      useNativeDriver: true,
    }).start();
  }, []);

  useEffect(() => {
    const storeLatestResult = async () => {
      if (fullResults.length > 0) {
        await AsyncStorage.setItem("lastCareerResult", JSON.stringify(fullResults));
      }
    };
    storeLatestResult();
  }, [fullResults]);

  const handleSaveSingle = async (title) => {
    const updated = [...new Set([...savedTitles, title])];
    await AsyncStorage.setItem("savedCareers", JSON.stringify(updated));
    setSavedTitles(updated);
  };

  const handleShare = async () => {
    try {
      const top = fullResults[0];
      const title = top?.title || t("result.defaultCareer");
      const emoji = careerEmojis[title] || "💻";
      await Share.share({
        message: t("result.shareMessage", { emoji, title }),
      });
    } catch (error) {
      console.error("Error sharing:", error);
    }
  };

  if (!answers) {
    return (
      <View style={styles.centered}>
        <Text style={styles.title}>{t("result.noAnswers")}</Text>
        <TouchableOpacity
          onPress={() => navigation.navigate("Questionnaire")}
          style={styles.button}
        >
          <Text style={styles.buttonText}>{t("result.takeQuiz")}</Text>
        </TouchableOpacity>
      </View>
    );
  }

  return (
    <View style={{ flex: 1 }}>
      {showConfetti && (
        <View style={{ position: "absolute", top: 0, left: 0, right: 0, zIndex: 999 }} pointerEvents="none">
          <ConfettiCannon
            count={150}
            origin={{ x: 200, y: -10 }}
            autoStart
            fadeOut
            fallSpeed={3000}
          />
        </View>
      )}

      <ScrollView
        contentContainerStyle={{ padding: 16, paddingBottom: 60 }}
        style={{ flex: 1, backgroundColor: colors.background }}
      >
        <NetworkBanner isConnected={isConnected} />
        {!isConnected && <OfflineBanner />}

        <Text style={[styles.title, { color: colors.text }]}>
          🎯 {t("result.title")}
        </Text>

        {showConfetti && (
          <Text style={{ fontSize: 26, textAlign: "center", marginBottom: 12 }}>
            {t("result.congrats")}
          </Text>
        )}

        {fullResults.map((career) => {
          const isSaved = savedTitles.includes(career.title);
          return (
            <TouchableOpacity
              key={career.title}
              onPress={() => openModal(career)}
              activeOpacity={0.9}
            >
              <View style={[styles.card, { backgroundColor: colors.card }]}>
                <Image
                  source={require("../assets/splash/splash.png")}
                  style={{
                    position: "absolute",
                    width: 90,
                    height: 90,
                    opacity: 0.25,
                    borderRadius: 45,
                    top: 0,
                    right: 10,
                    zIndex: -1,
                  }}
                />

                <Animated.View style={{ opacity: fadeAnim }}>
                  <View style={{ flexDirection: "row", alignItems: "center", marginBottom: 12 }}>
                    <View style={{
                      backgroundColor: "#e0e7ff",
                      paddingVertical: 6,
                      paddingHorizontal: 12,
                      borderRadius: 20,
                      flexDirection: "row",
                      alignItems: "center",
                    }}>
                      <Text style={{ fontSize: 18 }}>{careerEmojis[career.title] || "💼"}</Text>
                      <Text style={{ fontSize: 16, fontWeight: "bold", marginLeft: 8, color: "#1e3a8a" }}>
                        {career.title}
                      </Text>
                    </View>
                  </View>
                </Animated.View>

                <Text style={[styles.sectionTitle, { color: colors.text }]}>{t("dashboard.skills")}:</Text>
                <View style={styles.skillContainer}>
                  {career.skills?.map((skill, i) => (
                    <Text key={i} style={styles.skillTag}>{skill}</Text>
                  ))}
                </View>

                <Text style={[styles.sectionTitle, { color: colors.text }]}>{t("dashboard.roadmap")}:</Text>
                {career.roadmap?.slice(0, 5).map((step, i) => (
                  <Text key={i} style={[styles.smallText, { color: colors.text }]}>
                    • {step}
                  </Text>
                ))}

                {career.resources?.length > 0 && (
                  <>
                    <Text style={[styles.sectionTitle, { color: colors.text }]}>{t("dashboard.resources")}:</Text>
                    {career.resources.slice(0, 3).map((link) => (
                      <Text
                        key={career.title + "_link_" + link}
                        style={styles.link}
                        onPress={() => Linking.openURL(link)}
                      >
                        🔗 {link}
                      </Text>
                    ))}
                  </>
                )}

                <TouchableOpacity
                  onPress={() => handleSaveSingle(career.title)}
                  disabled={isSaved}
                  style={[
                    styles.button,
                    { backgroundColor: isSaved ? "#9ca3af" : "#4f46e5" },
                  ]}
                >
                  <Text style={styles.buttonText}>
                    {isSaved ? `✔ ${t("dashboard.saved")}` : t("dashboard.saveToDashboard")}
                  </Text>
                </TouchableOpacity>
              </View>
            </TouchableOpacity>
          );
        })}

        <View style={styles.buttonGroup}>
          <ThreeDButton
            title={t("result.share")}
            onPress={handleShare}
            gradient
          />

          <ThreeDButton
            title={t("result.retake")}
            onPress={() => navigation.navigate("Main", { screen: "Questionnaire" })}
            gradient
          />

          <ThreeDButton
            title={t("result.gotoDashboard")}
            onPress={() => navigation.navigate("DashboardLock")}
            gradient
          />

          <ThreeDButton
            title={t("backHome")}
            onPress={() => navigation.navigate("Main", { screen: "Home" })}
            gradient
          />
        </View>
      </ScrollView>

      <CareerModal visible={modalVisible} onClose={closeModal} career={selectedCareer} />
    </View>
  );
};

export default ResultScreen;

const styles = StyleSheet.create({
  title: {
    fontSize: 22,
    fontWeight: "bold",
    marginTop: 32,
    marginBottom: 16,
    textAlign: "center",
  },
  card: {
    padding: 16,
    borderRadius: 12,
    marginBottom: 16,
    overflow: "hidden",
  },
  skillContainer: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: 6,
    marginTop: 6,
    marginBottom: 10,
  },
  skillTag: {
    backgroundColor: "#e0e7ff",
    color: "#1e3a8a",
    fontSize: 12,
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 999,
    marginRight: 6,
    marginBottom: 6,
  },
  sectionTitle: {
    fontWeight: "600",
    marginTop: 8,
  },
  smallText: {
    fontSize: 14,
    marginTop: 4,
  },
  link: {
    fontSize: 14,
    marginTop: 4,
    color: "#2563eb",
    textDecorationLine: "underline",
  },
  button: {
    paddingVertical: 12,
    paddingHorizontal: 24,
    borderRadius: 8,
    marginTop: 8,
  },
  buttonText: {
    color: "white",
    fontWeight: "bold",
    textAlign: "center",
  },
  buttonGroup: {
    marginTop: 24,
    marginBottom: 40,
    alignItems: "center",
    gap: 12,
  },
  centered: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    padding: 24,
  },
});